﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnSpot : MonoBehaviour {

    public int teamId = 0;

	// Use this for initialization
	void Start () {
		
	}
}

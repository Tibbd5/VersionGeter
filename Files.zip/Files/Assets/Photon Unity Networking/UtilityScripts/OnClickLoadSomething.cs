// this class was moved into the Marco Polo Tutorial folder, as it's only used there
// this file is here to make sure the class is not defined 2 times.